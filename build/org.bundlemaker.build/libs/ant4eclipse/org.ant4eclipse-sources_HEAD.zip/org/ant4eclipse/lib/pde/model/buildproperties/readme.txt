~ Inkonsequente Implementierung.
~ Aufsplitten auf featureproject und pluginproject, gemeinsamen Teil hier lassen.